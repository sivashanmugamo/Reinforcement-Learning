'''
Author: @sivashanmugamo
'''

import os, math, time, pickle, random
import numpy as np

import tensorflow as tf

def a2c():
    '''
    '''
    pass

if __name__ == '__main__':
    a2c()